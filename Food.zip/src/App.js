import React ,{useState} from "react";
import Header from "./components/layout/Header";
import Meals from "./components/meals/Meals";
import Cart from "./components/cart/Cart";
import CartProvider from "./store/CartProvider"

function App() {
  const[isCartShown,setIsCartShown] = useState(false);

  const shownCartHandler=()=>{
    setIsCartShown(true);
  };

  const hideCartHandler=()=>{
    setIsCartShown(false);
  }
  return (
    <CartProvider>
      <Header  onShowCart={shownCartHandler}/>
      {
        isCartShown && <Cart  onCloseCart={hideCartHandler}/>
      }
      
      <main>
        <Meals />
      </main>
    </CartProvider>
  );
}

export default App;
