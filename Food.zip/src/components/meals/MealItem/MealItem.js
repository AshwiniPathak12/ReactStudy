import React ,{useContext} from "react";
import classes from "./MealItem.module.css";
import MealItemForm from "./MealItemForm";
import CartContext from "../../../store/CartContext";

const MealItem = (props) => {
const cartCtx = useContext(CartContext);
  const {meal} = props;
  const addToCartHandler=(amount)=>{
    cartCtx.addItem({
      id : meal.id ,
      name: meal.name ,
      amount :amount ,
      price : meal.price
    })
  }
  return (
    <li className={classes.meal}>
      <div>
        {/* <h3>Meal Item Name</h3> */}
        <h3>{meal.name}</h3>
        <div className={classes.description} > {meal.description} Meal Item Description</div>
        <div className={classes.price}> {meal.price}Price of Meal</div>
      </div>
      <MealItemForm id={meal.id} onAddToCart ={addToCartHandler}/>
      {/* <div>//Meal Item Form will go here</div> */}
    </li>
  );
};

export default MealItem;
