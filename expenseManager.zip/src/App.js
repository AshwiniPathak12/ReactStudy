import { useState } from "react";
import "./App.css";
import Expenses from "./components/Expenses/Expenses";
import NewExpense from "./components/NewExpenses/NewExpense";

const initialExpenses = [
  { id: 1, title: "shopping", date: new Date(2021, 1, 6), amount: 45000 },
  { id: 2, title: "Car wash", date: new Date(2020, 1, 5), amount: 78000 },
  { id: 3, title: "Travling", date: new Date(2023, 1, 1), amount: 24000 },
  
];
function App() {
const [expenses,setExpenses]= useState(initialExpenses);

  const addExpenseHandler = (expense) => {
   console.log(expense);
   setExpenses((prevExpenses)=>{
    return [expense,...prevExpenses];
   })
  };

  return (
    <div className="App">
      <h1>Expense Manger</h1>
      <NewExpense onAddExpense={addExpenseHandler}/>
      <Expenses expenses={expenses} />
      {/* <ExpenseItem /> */}
    </div>
  );
}

export default App;
