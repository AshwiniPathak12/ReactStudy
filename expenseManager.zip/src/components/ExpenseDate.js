import "./ExpenseDate.css";

//if (!obj) return; // Guard clause to handle undefined object
//const dateString = obj.date.toLocaleString();

const ExpenseDate = (props) => {
  const month = props.date.toLocaleString("en-us", {
    month: "long",
  });

  
  const year = props.date.getFullYear();
  const day = props.date.getDate();
  return (
    <div className="expence-date">
      <div className="expence-date_month">{month}</div>
      <div className="expence-date_year">{year}</div>
      <div className="expence-date_day">{day}</div>
    </div>
  );
};

export default ExpenseDate;
