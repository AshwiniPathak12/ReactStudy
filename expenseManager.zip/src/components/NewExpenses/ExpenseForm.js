import React, { useState } from "react";
import "./ExpenseFrom.css";
const ExpenseForm = (props) => {
  const [userInput, setUserInput] = useState({
    enteredTitle: "",
    enteredAmount: "",
    enteredDate: "",
  });

  const titleChangeHandler = (event) => {
    // console.log("title change handler trigger");
    // setUserInput({
    //     ...userInput,
    //     enteredTitle:event.target.value,

    // });

    setUserInput((prevState) => {
      return { ...prevState, enteredTitle: event.target.value };
    });
  };
  const amountChangeHandler = (event) => {
    // setUserInput({
    //   ...userInput,
    //   enteredAmount: event.target.value,
    // });
    setUserInput((prevState) => {
      return { ...prevState, enteredAmount: event.target.value };
    });
  };

  const dateChangedHandler = (event) => {
  

    setUserInput((prevState) => {
      return {
        ...prevState,

        enteredDate: event.target.value,
      };
    });
  };

  const submitHandler = (event) => {
    event.preventDefault();
    console.log("submit button click");
    const newExpense = {
      title: userInput.enteredTitle,
      amount: userInput.enteredAmount,
      date: new Date(userInput.enteredDate),
    };

    // console.log(newExpense);
    props.onSaveExpenseDate(newExpense);
    setUserInput({ enteredTitle: "", enteredAmount: "", enteredDate: "" });
  };
  return (
    <form onSubmit={submitHandler}>
      <div className="new-expense__controls">
        <div className="new-expense__control">
          <label>Title</label>
          <input
            type="text"
            onChange={titleChangeHandler}
            value={userInput.enteredTitle}
          />
        </div>
        <div className="new-expense__control">
          <label>Amount</label>
          <input
            type="number"
            onChange={amountChangeHandler}
            value={userInput.enteredAmount}
          />
        </div>
        <div className="new-expense__control">
          <label>Date: </label>
          <input
            type="date"
            min="2019-01-01"
            max="2026-12-31"
            onChange={dateChangedHandler}
            value={userInput.enteredDate}
          />
        </div>
        <div className="new-expense__actions">
          <button type="submit">Add Expense</button>
        </div>
      </div>
    </form>
  );
};

export default ExpenseForm;

// const ExpenseForm = () => {
//   return (
//     <form>
//       <div className="new-expense__controls">
//         <div className="new-expense__control">
//           <label>Title</label>
//           <input type="text" />
//         </div>
//         <div className="new-expense__control">
//           <label>Amount</label>
//           <input type="number" min="0.01" max="0.01" />
//         </div>
//         <div className="new-expense__control">
//           <label>Date</label>
//           <input type="date" min="2019-01-01" max="2022-12-31" />
//         </div>
//         <div className="new-expense__actions">
//           <button type="submit">Add Expense</button>
//         </div>
//       </div>
//     </form>
//   );
// };

// export default ExpenseForm;
