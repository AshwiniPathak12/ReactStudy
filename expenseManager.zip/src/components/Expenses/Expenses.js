import React from "react";
import Card from "../UI/Card";
import "./Expenses.css";
import ExpensesFilter from "./ExpenseFilter";
import { useState } from "react";
import { ExpenseList } from "./ExpenseList";
const Expenses = (props) => {
  const [filteredYear, setFilteredYear] = useState("2020");
  const { expenses } = props;
  console.log(expenses);

  const filterChangeHandler = (selectedYear) => {
    setFilteredYear(selectedYear);
  };

  const filteredExpenses = expenses.filter((expense) => {
    return expense.date.getFullYear().toString() === filteredYear;
  });
  // let expenseContent=<p>There is no expenses </p>;
  // if(filteredExpenses.length>0){
  //   expenseContent= filteredExpenses.map((expense)=>{
  //     return <ExpenseItem key={expense.id} expense={expense} />;
  //   })
  // }
  return (
    <Card className="expenses">
      <ExpensesFilter
        selected={filteredYear}
        onChangeFilter={filterChangeHandler}
      />

      <ExpenseList expenses={filteredExpenses} />
      {/* {expenseContent} */}

      {/* {
        filteredExpenses.length === 0 &&(<p>There is no expenses </p>)
      }
      {
        filteredExpenses.length>0 &&  filteredExpenses.map((expense)=>{
          return <ExpenseItem key={expense.id} expense={expense} />;
        })
      } */}

      {/* {expenses.map((expense) => {
        return <ExpenseItem key={expense.id} expense={expense} />;
      })} */}
    </Card>
  );
};

export default Expenses;
