import React from 'react';
import "./ExpenseList.css";
import ExpenseItem from './ExpenseItem';

export const ExpenseList = (props) => {
    if(props.expenses.length===0){
        return <h2 className='expense_list--fallback'>There is no expense</h2>
    }
  return (
    <ul className='expense-list'>
    {
        props.expenses.map((expense)=>{
            return <ExpenseItem key={expense.id} expense={expense}></ExpenseItem>
        })
    }


    </ul>
  )
}
