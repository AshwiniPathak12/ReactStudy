import { useState } from "react";
import Card from "../UI/Card";
import ExpenseDate from "./ExpenseDate";
import "./ExpenseItem.css";
const ExpenseItem = (props) => {
  // const expenseDate = props.expense.date.toLocaleString("en-us", {
  //   month: "long",
  // });

  //const {title} =props.expense;
  const [title,setTitle] =useState(props.expense.title)
   const expensePrice = props.expense.amount;
//  s
   return (
    <Card className="expense-item">
     <ExpenseDate date={props.expense.date}/>
      <div className="expense-item_description">
        <h2>{title}</h2>
        <div className="expense-item_price">
          <span>&#x20B9;</span>
          {expensePrice}
        </div>
      </div>
      {/* <button onClick={updateHandler}>Update</button> */}
    </Card>
  );
};

export default ExpenseItem;
