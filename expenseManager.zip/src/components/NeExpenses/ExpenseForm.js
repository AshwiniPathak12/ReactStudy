import React, { useState } from "react";
import "./ExpenseForm.css";

const ExpenseForm = (props) => {
  //const[enteredTitle,setEnteredTitle]=useState("");
  //const[enteredAmount,setEnteredAmount]=useState("");
  //const[enteredDate,setEnteredDate]=useState("");

  const [userInput, setUserInput] = useState({
    enteredTitle: "",
    enteredAmount: "",
    enteredDate: "",
  });

  const titleChangeHandler = (event) => {
    //console.log("Hi");
    // console.log(event.target.value);
    //setEnteredTitle(event.target.value);
    //  setUserInput({
    //   ...userInput,
    //  enteredTitle:event.target.value,
    // });

    setUserInput((preState) => {
      return {
        ...preState,
        enteredTitle: event.target.value,
      };
    });
  };

  const amountChangeHandler = (event) => {
    //console.log(event.target.value);
    //setEnteredAmount(event.target.value);
    // setUserInput({...userInput,
    //   enteredAmount:event.target.value,
    //  });

    setUserInput((preState) => {
      return {
        ...preState,
        enteredAmount: event.target.value,
      };
    });
  };

  const dateChangeHandler = (event) => {
    //console.log(event.target.value);
    //setEnteredDate(event.target.value);
    // setUserInput({...userInput,
    //   enteredDate:event.target.value,
    //  });
    setUserInput((preState) => {
      return {
        ...preState,
        enteredDate: event.target.value,
      };
    });
  };

  const submitHandler = (event) => {
    event.preventDefault();

    const newExpense = {
      title: userInput.enteredTitle,
      amount: userInput.enteredAmount,
      date: new Date(userInput.enteredDate),
    };
   // console.log(newExpense);
   props.onSaveExpenseDate(newExpense);
    setUserInput({ enteredTitle: "", enteredAmount: "", enteredDate: "" });
  };

  return (
    <form onSubmit={submitHandler}>
      <div className="new-expense__controls">
        <div className="new-expense__control">
          <label>Title</label>
          <input
            type="text"
            onChange={titleChangeHandler}
            value={userInput.enteredTitle}
          />
        </div>
        <div className="4new-expense__control">
          <label>Amount</label>
          <input
            type="number"
            onChange={amountChangeHandler}
            value={userInput.enteredAmount}
          />
        </div>
        <div className="new-expense__control">
          <label>Date</label>
          <input
            type="date"
            onChange={dateChangeHandler}
            value={userInput.enteredDate}
            min="2019-01-01"
            max="2026-12-31"
          />
        </div>
        <div className="new-expense__actions">
          <button type="submit">Add Expense</button>
        </div>
      </div>
    </form>
  );
};

export default ExpenseForm;
