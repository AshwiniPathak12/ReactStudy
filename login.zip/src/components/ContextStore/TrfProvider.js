// import React, { createContext, useReducer } from "react";

// const initialState = {
//   trfData: [
//     {
//       id: 1,

//       trainingTitle: "Java Trainning for Testing Pool",

//       intiatedFrom: "Vikas Pandharpurkar",

//       trainingType: "FRW(Future Ready Workforce)",

//       resourceType: "On Bench",

//       skillsToBeImparted: "Java",

//       startDate: new Date(2021, 1, 6),

//       endDate: new Date(2022, 1, 13),

//       projectName: "hjk",

//       duration: 30,

//       noOfParticipent: 30,

//       purposeOfTraining: "Capablity Building",
//     },
//   ],
// };

// export const TrfContext = createContext(initialState);

// const trfReducer = (state, action) => {
//   switch (action.type) {
//     case "ADD_TRF":
//       return {
//         ...state,

//         trfData: [...state.trfData, action.payload],
//       };

//     default:
//       return state;
//   }
// };

// const TrfProvider = ({ children }) => {
//   const [trfState, trfDispatchAction] = useReducer(trfReducer, initialState);

//   const addTrf = (trf) => {
//     trfDispatchAction({
//       type: "ADD_TRF",

//       payload: trf,
//     });
//   };

//   return (
//     <TrfContext.Provider
//       value={{
//         trfData: trfState.trfData,
//         addTrf,
//       }}
//     >
//       {children}
//     </TrfContext.Provider>
//   );
// };

// export default TrfProvider;
