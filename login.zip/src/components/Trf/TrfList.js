// import React from "react";
// import "./TrfList.css";
// import Dates from "./Dates";
// import { useContext } from "react";

// import { TrfContext } from "../store/TrfProvider";

// const TrfList = () => {
//     const { trfData } = useContext(TrfContext);

//   console.log(trfData);

//   return (
//     <div className="trf">
      

//       <div>
//         <table className="tb">
//           <thead className="th">
//             <tr>
//               <th>Id</th>

//               <th>Training Title</th>

//               <th>Initiated from</th>

//               <th>Training Type</th>

//               <th>Project Name</th>

//               <th>Resource Type</th>

//               <th>Duration(In Days)</th>

//               <th>No of participants</th>

//               <th>Skills to be imparted</th>

//               <th>Training Start Date(dd-mm-yyyy)</th>

//               <th>Training End Date(dd-mm-yyyy)</th>

//               <th>Purpose of training</th>
//             </tr>
//           </thead>

//           <tbody className="td">
//             {trfData.map((val, key) => {
//               return (
//                 <tr key={key}>
//                   <td>{key + 1}</td>

//                   <td>{val.trainingTitle}</td>

//                   <td>{val.trainingType}</td>

//                   <td>{val.intiatedFrom}</td>

//                   <td>{val.projectName}</td>

//                   <td>{val.resourceType}</td>

//                   <td>{val.skillsToBeImparted}</td>

//                   <td>{val.duration}</td>

//                   <td>{val.noOfParticipent}</td>

//                   <td>
//                     {" "}
//                     <Dates date={val.startDate} />
//                   </td>

//                   <td>
//                     {" "}
//                     <Dates date={val.endDate} />
//                   </td>

//                   <td>{val.purposeOfTraining}</td>
//                 </tr>
//               );
//             })}
//           </tbody>
//         </table>
//       </div>

     
//     </div>
//   );
// };

// export default TrfList;
