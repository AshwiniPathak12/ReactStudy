// import React from "react";

// const Dates = (props) => {
//   const month = props.date?.toLocaleString("en-us", {
//     month: "short",
//   });

//   const year = props.date?.getFullYear();

//   const day = props.date?.getDate();

//   return (
//     <div className="trf-date">
//       <div className="trf-date_month">
//         {day}-{month}-{year}
//       </div>

    
//     </div>
//   );
// };

// export default Dates;
