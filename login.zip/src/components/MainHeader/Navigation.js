import React from "react";
import {  NavLink } from "react-router-dom";
import classes from "./Navigation.module.css";

const Navigation = (props) => {

  const navLinkStyle = ({ isActive }) => {

    return {
      fontWeight: isActive ? "bold" : "normal",
      textDecoration: isActive ? "underline" : "none",
      };
      };
  return (
    <nav className={classes.nav}>
      <ul>
        {/* {props.isLoggedIn && (
          <li>
            <a href="/">Users</a>
          </li>
        )} */}
        {props.isLoggedIn && (
          <li>
            <NavLink style={navLinkStyle} to="/TrainingInitiatiorSection">
              Add Trf
            </NavLink>
          </li>
        )}
        {props.isLoggedIn && (
          <li>
            <NavLink style={navLinkStyle} to="/">
              <button onClick={props.onLogout}>Logout</button>
            </NavLink>
          </li>
        )}
      </ul>
    </nav>
  );
};

export default Navigation;
