import React from "react";
//import TrfList from "../Trf/TrfList";

import classes from "./Home.module.css";
import TRFList from "../../toolkit/pages/TRFList";



const Home = () => {
  return (
    <React.Fragment>

    <div className={classes.home}>
        <div className="container mx-auto">
          <h3 className="text-center text-3xl mt-20 text-base leading-8 text-black font-bold tracking-wide uppercase">
          </h3>

          <TRFList/>
        </div>
    
      
    </div>
    </React.Fragment>
  );
};

export default Home;
