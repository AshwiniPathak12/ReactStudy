//npm run json-server
import "./App.css";
import React, { useState, useEffect } from "react";

import Login from "./components/Login/Login";
import Home from "./components/Home/Home";
import MainHeader from "./components/MainHeader/MainHeader";
//import TrfProvider from "./components/AAAsstore/TrfProvider";
import { Routes, Route } from "react-router-dom";
import TrainingInitiatiorSection from "./toolkit/pages/TrainingInitiatiorSection";
import ImportExcelData from "./components/Trf/EmployeeData/ImportExcelData";

//import TrainingInitiatiorSection from "./components/Trf/TrainingInitiatiorSection";
//import ImportExcelData from "./components/Trf/EmployeeData/ImportExcelData";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const loginHandler = (email, password) => {
    localStorage.setItem("isLoggedIn", "1");
    setIsLoggedIn(true);
  };

  useEffect(() => {
    const userLoggedInStauts = localStorage.getItem("isLoggedIn");
    if (userLoggedInStauts === "1") {
      setIsLoggedIn(true);
    }
  }, []);

  const logoutHandler = () => {
    localStorage.removeItem("isLoggedIn");
    setIsLoggedIn(false);
  };

  return (
    <React.Fragment>
      <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler} />

      {/* <TrfProvider> */}
      <div className="App">
        <Routes>
          <Route
            path="/"
            element={!isLoggedIn && <Login onLogin={loginHandler} />}
            exact
          />
          <Route
            path="/home"
            element={isLoggedIn && <Home onLogout={logoutHandler} />}
            exact
          />

          <Route
            path="/TrainingInitiatiorSection"
            element={<TrainingInitiatiorSection />}
            exact
          />

          <Route
            path="/add-employee-excelsheet"
            element={<ImportExcelData />}
          />
        </Routes>
      </div>
      {/* </TrfProvider> */}
    </React.Fragment>
  );
}

export default App;
