import { configureStore } from "@reduxjs/toolkit";

import trainingInitiatiorSectionSlice from "../toolkit/features/trainingInitiarors/trainingInitiatiorSectionSlice";

import registrationSlice from "../toolkit/features/registration/registrationSlice";

export const store = configureStore({
  reducer: {
    trf: trainingInitiatiorSectionSlice,

    registration: registrationSlice,
  },
});
