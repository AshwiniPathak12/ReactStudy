import axios from "axios";

const { createSlice, createAsyncThunk } = require("@reduxjs/toolkit");

export const fetchAllRegistration = createAsyncThunk(
  "registration/registration-list",

  async () => {
    const response = await axios.get("http://localhost:4000/registration");

    return response.data;
  }
);

export const saveRegistration = createAsyncThunk(
  "registration/createAPI",
  async (payload) => {
    const response = await axios.post(
      "http://localhost:4000/registration",
      payload
    );

    return response.data;
  }
);

const initialState = {
  trfRegitration: [],

  loading: "idle",
};

const registrationSlice = createSlice({
  name: "registration",

  initialState,

  reducers: {},

  extraReducers: (builder) => {
    builder.addCase(fetchAllRegistration.pending, (state, action) => {
      state.loading = "pending";
    });

    builder.addCase(fetchAllRegistration.fulfilled, (state, action) => {
      state.loading = "idle";

      state.trfRegitration = action.payload;
    });

    builder.addCase(saveRegistration.pending, (state, action) => {
      state.loading = "pending";
    });

    builder.addCase(saveRegistration.fulfilled, (state, action) => {
      state.loading = "idle";

      state.trfRegitration.unshift(action.payload);
    });
  },
});

export const getAllRegistration = (state) => state.registration.trfRegitration;
export const getLoading = (state) => state.registration.loading;
export default registrationSlice.reducer;
