import {useState} from "react";
import './App.css';
import UserList from "./component/User/UserList"
import AddMyUSer from "./component/User/AddMyUSer";


const initailUserList=[
  {id:1,userName:"seeta",age:28},
  {id:2,userName:"geeta",age:30},
];
function App() {

  const [userList,setUserList]=useState(initailUserList);

  const addUserHAndler=(user)=>{
    setUserList((preState)=>{
      return [user, ...preState];
    })
  };
  return (
    <div className="App">
      <h2>User App-Error Managment</h2>
      <AddMyUSer onAddUser={addUserHAndler}/>
      <UserList users={userList} />       
    </div>


  );
}

export default App;
