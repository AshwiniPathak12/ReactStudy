import React, { useRef, useState } from "react";
import Card from "../UI/Card";
import classes from "./AddUser.module.css";
import Button from "../UI/Button";
import ErrorModal from "../UI/ErrorModal";

const AddMyUSer = (props) => {
  const nameInputRef=useRef();
  //const [enteredUserName, setEnteredUserName] = useState("");
const ageInputRef=useRef();
  //const [enteredAge, setEnteredAge] = useState("");
  const [error, setError] = useState();

  // const userNameChangeHandler = (event) => {
  //   setEnteredUserName(event.target.value);
  // };
  // const ageChangeHandler = (event) => {
  //   setEnteredAge(event.target.value);
  // };

  const addUserHandler = (event) => {
    event.preventDefault();

    //console.log('-------AddUserHandler--------');
    //Name and Age validation -- non empty
    const enteredUserName = nameInputRef.current.value;
    const enteredAge = ageInputRef.current.value;

    if (enteredUserName.trim().length === 0 || enteredAge.trim().length === 0) {
      setError({
        title: "Invalid Input",

        message: "Please Enter a Valid(non empty)",
      });

      return;
    }

    //age should not be negative

    if (+enteredAge < 1) {
      setError({
        title: "Invalid Input",

        message: "Please Enter a Valid Age greater then 0",
      });

      return;
    }

    const newUser = {
      id: Math.random().toString(),

      userName: enteredUserName,

      age: enteredAge,
    };

    props.onAddUser(newUser);

   // setEnteredUserName("");
    //setEnteredAge("");

    //use current.value to clear 
    nameInputRef.current.value = "";
    
    ageInputRef.current.value = "";
  };

  const errorHadler = () => {
    setError(null);
  };

  return (
    <div>
      {error && (
        <ErrorModal
          onConfirm={errorHadler}
          title={error.title}
          message={error.message}
        />
      )}

      <Card className={classes.input}>
        <form onSubmit={addUserHandler}>
          <label htmlFor="userName">UserName </label>

          <input
            id="userName"
            type="text"
            name="userName"
            // value={enteredUserName}
            // onChange={userNameChangeHandler}
            ref={nameInputRef}
          />

          <label htmlFor="age">Age</label>

          <input
            id="age"
            type="number"
            //value={enteredAge}
            //onChange={ageChangeHandler}
            ref={ageInputRef}
          />

          <Button type="submit">AddUser</Button>
        </form>
      </Card>
    </div>
  );
};

export default AddMyUSer;
